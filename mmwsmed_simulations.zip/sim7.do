* sim7.do

version 16
clear all
set more off
local designs h40 h20 h10 h00
local sizes 800 5000
local reps 500
local B 200

capture program drop nr4_gen
program nr4_gen
	args d n
	drop _all
	quietly set obs `n'
	forvalues j = 1/3 {
		quietly generate double x`j' = rnormal()
	}
	quietly generate double w1 = rnormal()
	quietly generate byte w2 = runiform() < .5
	local lev = real(substr("`d'", 2, 2))/100
	quietly generate byte a = runiform() < invlogit(.5*x1 - .5*x2 + .3*x3 + .8*w1 + .8*(w2 - .5))
	quietly generate double m = a + .5*(x1 + x2 + x3) + .5*w1 + exp(.5*(1.5*`lev'*x1 + `lev'*a*x2))*rnormal()
	quietly generate double y = .3*a + (.5 + .2*a)*m + .5*(x1 + x2 + x3) + .4*w1 + .4*w2 + rnormal()
end

local c_het_ts    (y) (m x1 x2 x3 w1) (a x1 x2 x3 w1 w2), all heteroskedastic
local c_het_bs    (y) (m x1 x2 x3 w1) (a x1 x2 x3 w1 w2), all heteroskedastic vce(bootstrap, reps(`B') nodots)
local c_const_ts  (y) (m x1 x2 x3 w1) (a x1 x2 x3 w1 w2), all
local c_const_bs  (y) (m x1 x2 x3 w1) (a x1 x2 x3 w1 w2), all vce(bootstrap, reps(`B') nodots)

set seed 2043
tempname pf
postfile `pf' str3 design int n int rep str8 method double(de se_de ie se_ie) int nmis ///
	using "C:\Users\Ariel\Desktop\MMWSMED\nr4_sim_results.dta", replace
foreach d of local designs {
	local methods het_ts het_bs
	if "`d'" == "h00" local methods het_ts het_bs const_ts const_bs
	foreach n of local sizes {
		di as txt _n "design `d', N = `n'" _c
		forvalues r = 1/`reps' {
			if mod(`r', 25) == 0 di as txt "." _c
			nr4_gen `d' `n'
			foreach m of local methods {
				capture quietly mmwsmed `c_`m''
				if _rc {
					post `pf' ("`d'") (`n') (`r') ("`m'") (.) (.) (.) (.) (.)
					continue
				}
				local nm = cond(missing(e(N_misreps)), 0, e(N_misreps))
				post `pf' ("`d'") (`n') (`r') ("`m'") (_b[NDE:r1vs0.a]) (_se[NDE:r1vs0.a]) ///
					(_b[NIE:r1vs0.a]) (_se[NIE:r1vs0.a]) (`nm')
			}
		}
	}
}
postclose `pf'

use "C:\Users\Ariel\Desktop\MMWSMED\nr4_sim_results.dta", clear
quietly generate double tde = .3
quietly generate double tie = .7
foreach e in de ie {
	quietly generate byte cov_`e' = abs(`e' - t`e') <= invnormal(.975)*se_`e' if !missing(`e')
}
quietly generate byte fail = missing(de)
collapse (mean) de ie tde tie se_de se_ie cov_de cov_ie nmis (sd) sd_de=de sd_ie=ie (sum) nfail=fail ///
	(count) nrep=de, by(design n method)
foreach e in de ie {
	quietly generate double bias_`e' = `e' - t`e'
	quietly generate double ratio_`e' = se_`e'/sd_`e'
}
generate byte morder = cond(method == "het_ts", 1, cond(method == "het_bs", 2, cond(method == "const_ts", 3, 4)))
generate byte dorder = cond(design == "h40", 1, cond(design == "h20", 2, cond(design == "h10", 3, 4)))
sort dorder n morder
format tde tie bias_* sd_* se_* ratio_* cov_* %7.3f
format nmis %6.1f
foreach e in ie de {
	di _n as res cond("`e'" == "de", "Natural direct effect (NDE)", "Natural indirect effect (NIE)")
	list design n method t`e' bias_`e' sd_`e' se_`e' ratio_`e' cov_`e' nfail nmis nrep, sepby(design n) noobs abbreviate(12)
}
save "C:\Users\Ariel\Desktop\MMWSMED\nr4_sim_summary.dta", replace

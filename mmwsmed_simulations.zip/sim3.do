* sim3.do

version 16
clear all
set more off
local reps 1000
local designs cm1 cm2 cnt bo co t3

capture program drop ext_gen
program ext_gen
	args d n
	drop _all
	quietly set obs `n'
	forvalues j = 1/3 {
		quietly generate double x`j' = rnormal()
	}
	local sx (x1 + x2 + x3)
	if "`d'" == "t3" quietly generate byte a = floor(3*runiform())
	else             quietly generate byte a = runiform() < .5
	if inlist("`d'", "cm1", "cm2") {
		quietly generate double u = rnormal()
		if "`d'" == "cm1" quietly generate double m = cond(a == 1, .5 + .5*`sx' + u, .5*`sx' + u)
		else              quietly generate double m = cond(a == 1, .5 + .25*x2 + .5*x3 + 1.2*u, .5*x1 + .25*x2 + u)
		quietly generate double y = .2*a + .4*m + .3*a*m + .5*`sx' + rnormal()
	}
	else if "`d'" == "cnt" {
		quietly generate double m = rpoisson(exp(cond(a == 1, 1.0423622887 + .15*x2 + .3*x3, 0.6368971806 + .3*x1 + .15*x2)))
		quietly generate double y = .2*a + .3*m + .1*a*m + .5*`sx' + rnormal()
	}
	else if inlist("`d'", "bo", "co") {
		quietly generate byte m = runiform() < invlogit(cond(a == 1, 0.8332440052 + .5*x2 + x3, -0.5505294554 + x1 + .5*x2))
		if "`d'" == "bo" quietly generate byte y = runiform() < invlogit(-1 + .6*a + 1.2*m + .4*a*m + .4*`sx')
		else             quietly generate double y = rpoisson(exp(.3*a + .7*m - .2*a*m + .2*`sx'))
	}
	else {
		quietly generate byte m = runiform() < invlogit(cond(a == 0, -0.5077589818 + x1 + .5*x2, ///
			cond(a == 1, 0.5077589818 + .5*x2 + x3, 1.2657985030 + .5*`sx')))
		quietly generate double y = cond(a == 0, 0, cond(a == 1, .3, .5)) + cond(a == 0, .6, cond(a == 1, .8, 1))*m ///
			+ .5*`sx' + rnormal()
	}
end

local meth_cm1 naive rmpw rmpw_ts odds odds_ts
local meth_cm2 `meth_cm1'
local meth_cnt naive rmpw rmpw_ts
local meth_bo  naive rmpw rmpw_ts nrmpw4
local meth_co  `meth_bo'
local meth_t3  naive rmpw rmpw_ts nrmpw3
foreach d in cm1 cm2 {
	local c_`d'_naive   (y) (m) (a), all knownweights
	local c_`d'_rmpw    (y) (m x1 x2 x3) (a), all knownweights
	local c_`d'_rmpw_ts (y) (m x1 x2 x3) (a), all vce(twostep)
	local c_`d'_odds    (y) (m x1 x2 x3) (a), all mweight(odds) knownweights
	local c_`d'_odds_ts (y) (m x1 x2 x3) (a), all mweight(odds) vce(twostep)
}
local c_cnt_naive   (y) (m, poisson) (a), all knownweights
local c_cnt_rmpw    (y) (m x1 x2 x3, poisson) (a), all knownweights
local c_cnt_rmpw_ts (y) (m x1 x2 x3, poisson) (a), all vce(twostep)
foreach d in bo co {
	local om = cond("`d'" == "bo", "logit", "poisson")
	local c_`d'_naive   (y, `om') (m, logit) (a), all knownweights
	local c_`d'_rmpw    (y, `om') (m x1 x2 x3, logit) (a), all knownweights
	local c_`d'_rmpw_ts (y, `om') (m x1 x2 x3, logit) (a), all vce(twostep)
	local c_`d'_nrmpw4  (y, `om') (m x1 x2 x3, logit) (a), all nonparametric strata(4 4) knownweights
}
local c_t3_naive   (y) (m, logit) (a), all knownweights
local c_t3_rmpw    (y) (m x1 x2 x3, logit) (a), all knownweights
local c_t3_rmpw_ts (y) (m x1 x2 x3, logit) (a), all vce(twostep)
local c_t3_nrmpw3  (y) (m x1 x2 x3, logit) (a), all nonparametric strata(3 3) knownweights

set seed 2026
tempname pf
postfile `pf' str3 design int n int rep str7 method double(de1 se_de1 ie1 se_ie1 de2 se_de2 ie2 se_ie2) int nused ///
	using "C:\Users\Ariel\Desktop\MMWSMED\ext_sim_results.dta", replace
foreach d of local designs {
	foreach n in 5000 800 {
		di as txt _n "design `d', N = `n'" _c
		forvalues r = 1/`reps' {
			if mod(`r', 50) == 0 di as txt "." _c
			ext_gen `d' `n'
			foreach m of local meth_`d' {
				capture quietly mmwsmed `c_`d'_`m''
				if _rc {
					post `pf' ("`d'") (`n') (`r') ("`m'") (.) (.) (.) (.) (.) (.) (.) (.) (.)
					continue
				}
				local r2 (.) (.) (.) (.)
				if "`d'" == "t3" local r2 (_b[NDE:r2vs0.a]) (_se[NDE:r2vs0.a]) (_b[NIE:r2vs0.a]) (_se[NIE:r2vs0.a])
				post `pf' ("`d'") (`n') (`r') ("`m'") (_b[NDE:r1vs0.a]) (_se[NDE:r1vs0.a]) (_b[NIE:r1vs0.a]) ///
					(_se[NIE:r1vs0.a]) `r2' (e(N))
			}
		}
	}
}
postclose `pf'

use "C:\Users\Ariel\Desktop\MMWSMED\ext_sim_results.dta", clear
quietly reshape long de se_de ie se_ie, i(design n rep method) j(t)
quietly drop if t == 2 & design != "t3"
generate double tde = .
generate double tie = .
quietly replace tde = .2 if inlist(design, "cm1", "cm2")
quietly replace tie = .35 if inlist(design, "cm1", "cm2")
quietly replace tde = .4 if design == "cnt"
quietly replace tie = .4 if design == "cnt"
quietly replace tde = 0.1447886956 if design == "bo"
quietly replace tie = 0.0925396234 if design == "bo"
quietly replace tde = 0.3054873053 if design == "co"
quietly replace tie = 0.2445417392 if design == "co"
quietly replace tde = cond(t == 1, .38, .66) if design == "t3"
quietly replace tie = cond(t == 1, .16, .35) if design == "t3"
foreach e in de ie {
	generate double sqe_`e' = (`e' - t`e')^2
	generate byte cov_`e' = abs(`e' - t`e') <= invnormal(.975)*se_`e' if !missing(`e')
}
collapse (mean) de ie tde tie se_de se_ie mse_de=sqe_de mse_ie=sqe_ie cov_de cov_ie (sd) sd_de=de sd_ie=ie ///
	(count) nrep=de, by(design t n method)
foreach e in de ie {
	generate double bias_`e' = `e' - t`e'
	generate double sebias_`e' = se_`e' - sd_`e'
	bysort design t n: egen double nb_`e' = max(cond(method == "naive", bias_`e', .))
	bysort design t n: egen double nv_`e' = max(cond(method == "naive", sd_`e'^2, .))
	generate double remov_`e' = 1 - abs(bias_`e')/abs(nb_`e')
	generate double releff_`e' = nv_`e'/sd_`e'^2
}
generate byte morder = cond(method == "naive", 1, cond(method == "rmpw", 2, cond(method == "rmpw_ts", 3, ///
	cond(method == "odds", 4, cond(method == "odds_ts", 5, 6)))))
generate byte dorder = cond(design == "cm1", 1, cond(design == "cm2", 2, cond(design == "cnt", 3, ///
	cond(design == "bo", 4, cond(design == "co", 5, 6)))))
sort dorder t n morder
format tde tie bias_* sebias_* remov_* releff_* mse_* cov_* %7.3f
foreach e in ie de {
	di _n as txt cond("`e'" == "de", "Natural direct effect (NDE)", "Natural indirect effect (NIE)")
	list design t n method t`e' bias_`e' remov_`e' releff_`e' mse_`e' sebias_`e' cov_`e' nrep, ///
		sepby(design t n) noobs abbreviate(12)
}
save "C:\Users\Ariel\Desktop\MMWSMED\ext_sim_summary.dta", replace

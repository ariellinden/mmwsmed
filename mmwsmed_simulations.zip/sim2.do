* sim2.do

version 16
clear all
set more off
local designs q25 q50 q100 i25 i50 i100
local reps 1000

capture program drop hdh2_gen
program hdh2_gen
	args d n
	drop _all
	quietly set obs `n'
	forvalues j = 1/3 {
		quietly generate double x`j' = rnormal()
	}
	if "`d'" == "q25"  {
		local a0 -0.4892812605
		local a1  0.8834165039
	}
	if "`d'" == "q50"  {
		local a0 -0.4402349428
		local a1  0.9374944090
	}
	if "`d'" == "q100" {
		local a0 -0.3513434275
		local a1  1.1085148290
	}
	if "`d'" == "i25"  {
		local a0 -0.5211350314
		local a1  0.8605621989
	}
	if "`d'" == "i50"  {
		local a0 -0.4996555988
		local a1  0.8862187146
	}
	if "`d'" == "i100" {
		local a0 -0.4932659512
		local a1  0.9344671813
	}
	local deg = real(substr("`d'", 2, .))/100
	if substr("`d'", 1, 1) == "q" {
		local g0 (x1^2 - 1)
		local g1 (x3^2 - 1)
	}
	else {
		local g0 (x1*x2)
		local g1 (x2*x3)
	}
	quietly generate byte a = runiform() < .5
	quietly generate double u = runiform()
	quietly generate byte z0 = u < invlogit(`a0' + x1 + .5*x2 + `deg'*`g0')
	quietly generate byte z1 = u < invlogit(`a1' + .5*x2 + x3 + `deg'*`g1')
	quietly generate byte z = cond(a == 1, z1, z0)
	quietly generate double y = cond(a == 0 & z == 0, 0, cond(a == 1 & z == 0, 2.1582, cond(a == 0 & z == 1, .5, ///
		2.1582 + .5 - 3.5))) + .5*(x1 + x2 + x3) + rnormal()
end

set seed 2051
tempname pf
postfile `pf' str4 design int n int rep str9 method double(de se_de ie se_ie) int nused ///
	using "C:\Users\Ariel\Desktop\MMWSMED\hdh2_sim_results.dta", replace
foreach d of local designs {
	if substr("`d'", 1, 1) == "q" local tterms c.x1#c.x1 c.x3#c.x3
	else                          local tterms c.x1#c.x2 c.x2#c.x3
	foreach n in 800 5000 {
		di as txt _n "design `d', N = `n'" _c
		forvalues r = 1/`reps' {
			if mod(`r', 50) == 0 di as txt "." _c
			hdh2_gen `d' `n'
			foreach m in naive rmpw rmpw_true nrmpw3 nrmpw4 {
				if "`m'" == "naive"     local cmd mmwsmed (y) (z, logit) (a), all
				if "`m'" == "rmpw"      local cmd mmwsmed (y) (z x1 x2 x3, logit) (a), all
				if "`m'" == "rmpw_true" local cmd mmwsmed (y) (z x1 x2 x3 `tterms', logit) (a), all
				if "`m'" == "nrmpw3"    local cmd mmwsmed (y) (z x1 x2 x3, logit) (a), all nonparametric strata(3 3)
				if "`m'" == "nrmpw4"    local cmd mmwsmed (y) (z x1 x2 x3, logit) (a), all nonparametric strata(4 4)
				capture quietly `cmd'
				if _rc post `pf' ("`d'") (`n') (`r') ("`m'") (.) (.) (.) (.) (.)
				else post `pf' ("`d'") (`n') (`r') ("`m'") (_b[NDE:r1vs0.a]) (_se[NDE:r1vs0.a]) (_b[NIE:r1vs0.a]) ///
					(_se[NIE:r1vs0.a]) (e(N))
			}
		}
	}
}
postclose `pf'

use "C:\Users\Ariel\Desktop\MMWSMED\hdh2_sim_results.dta", clear
quietly generate double tde = .7869
quietly generate double tie = -.8073
foreach e in de ie {
	quietly generate double sqe_`e' = (`e' - t`e')^2
	quietly generate byte cov_`e' = abs(`e' - t`e') <= invnormal(.975)*se_`e' if !missing(`e')
}
quietly generate byte fail = missing(de)
collapse (mean) de ie tde tie se_de se_ie mse_de=sqe_de mse_ie=sqe_ie cov_de cov_ie (sd) sd_de=de sd_ie=ie ///
	(sum) nfail=fail (count) nrep=de, by(design n method)
foreach e in de ie {
	quietly generate double bias_`e' = `e' - t`e'
	quietly generate double rmse_`e' = sqrt(mse_`e')
	bysort design n: egen double nb_`e' = max(cond(method == "naive", bias_`e', .))
	quietly generate double remov_`e' = 1 - abs(bias_`e')/abs(nb_`e')
}
generate byte morder = cond(method == "naive", 1, cond(method == "rmpw", 2, cond(method == "rmpw_true", 3, ///
	cond(method == "nrmpw3", 4, 5))))
generate byte dorder = 0
local j 0
foreach d in q25 q50 q100 i25 i50 i100 {
	local ++j
	quietly replace dorder = `j' if design == "`d'"
}
sort dorder n morder
format tde tie bias_* remov_* sd_* se_* cov_* rmse_* %7.3f
foreach e in ie de {
	di _n as res cond("`e'" == "de", "Natural direct effect (NDE)", "Natural indirect effect (NIE)")
	list design n method t`e' bias_`e' remov_`e' sd_`e' se_`e' cov_`e' rmse_`e' nfail nrep, sepby(design n) noobs abbreviate(12)
}
save "C:\Users\Ariel\Desktop\MMWSMED\hdh2_sim_summary.dta", replace

* sim4.do

version 16
clear all
set more off
local reps 1000
local designs nb nc nm

capture program drop nr_gen
program nr_gen
	args d n
	drop _all
	quietly set obs `n'
	forvalues j = 1/3 {
		quietly generate double x`j' = rnormal()
	}
	quietly generate double w1 = rnormal()
	quietly generate byte w2 = runiform() < .5
	local sx (x1 + x2 + x3)
	local v1 (.5*x1 - .5*x2 + .3*x3 + .8*w1 + .8*(w2 - .5))
	local v2 (-.3*x1 + .5*x2 + .5*x3 + .5*w1 - .8*(w2 - .5))
	if "`d'" != "nm" {
		quietly generate byte a = runiform() < invlogit(`v1')
	}
	else {
		tempvar u
		quietly generate double `u' = runiform()
		quietly generate byte a = (`u' > 1/(1 + exp(`v1') + exp(`v2'))) + (`u' > (1 + exp(`v1'))/(1 + exp(`v1') + exp(`v2')))
	}
	if "`d'" == "nb" {
		quietly generate byte m = runiform() < invlogit(cond(a == 1, 0.8611384443 + .5*x2 + x3, -0.5690750539 + x1 + .5*x2) + .5*w1)
		quietly generate double y = .3*a + (.6 + .3*a)*m + .5*`sx' + .4*w1 + .4*w2 + rnormal()
	}
	else if "`d'" == "nc" {
		quietly generate double m = a + .5*`sx' + .5*w1 + rnormal()
		quietly generate byte y = runiform() < invlogit(-1 + .5*a + (.6 + .2*a)*m + .3*`sx' + .4*w1 + .4*(w2 - .5))
	}
	else {
		quietly generate byte m = runiform() < invlogit(cond(a == 0, -0.5248761443 + x1 + .5*x2, ///
			cond(a == 1, 0.5248761443 + .5*x2 + x3, 1.3149122390 + .5*`sx')) + .5*w1)
		quietly generate double y = cond(a == 0, 0, cond(a == 1, .3, .5)) + cond(a == 0, .6, cond(a == 1, .8, 1))*m ///
			+ .5*`sx' + .4*w1 + .4*w2 + rnormal()
	}
end

local methods naive medonly iptw iptw_ts mmws5 mmws10 tmis
foreach d in nb nc nm {
	local mo = cond("`d'" == "nc", "", ", logit")
	local oe = cond("`d'" == "nc", "(y, logit)", "(y)")
	local c_`d'_naive   `oe' (m`mo') (a), all knownweights
	local c_`d'_medonly `oe' (m x1 x2 x3 w1`mo') (a), all knownweights
	local c_`d'_iptw    `oe' (m x1 x2 x3 w1`mo') (a x1 x2 x3 w1 w2), all knownweights
	local c_`d'_iptw_ts `oe' (m x1 x2 x3 w1`mo') (a x1 x2 x3 w1 w2), all vce(twostep)
	local c_`d'_mmws5   `oe' (m x1 x2 x3 w1`mo') (a x1 x2 x3 w1 w2, tmethod(mmws) tstrata(5)), all knownweights
	local c_`d'_mmws10  `oe' (m x1 x2 x3 w1`mo') (a x1 x2 x3 w1 w2, tmethod(mmws) tstrata(10)), all knownweights
	local c_`d'_tmis    `oe' (m x1 x2 x3 w1`mo') (a x1 x2 x3 w1), all knownweights
}

set seed 2027
tempname pf
postfile `pf' str3 design int n int rep str7 method double(de1 se_de1 ie1 se_ie1 de2 se_de2 ie2 se_ie2) int nused ///
	using "C:\Users\Ariel\Desktop\MMWSMED\nr_sim_results.dta", replace
foreach d of local designs {
	foreach n in 5000 800 {
		di as txt _n "design `d', N = `n'" _c
		forvalues r = 1/`reps' {
			if mod(`r', 50) == 0 di as txt "." _c
			nr_gen `d' `n'
			foreach m of local methods {
				capture quietly mmwsmed `c_`d'_`m''
				if _rc {
					post `pf' ("`d'") (`n') (`r') ("`m'") (.) (.) (.) (.) (.) (.) (.) (.) (.)
					continue
				}
				local r2 (.) (.) (.) (.)
				if "`d'" == "nm" local r2 (_b[NDE:r2vs0.a]) (_se[NDE:r2vs0.a]) (_b[NIE:r2vs0.a]) (_se[NIE:r2vs0.a])
				post `pf' ("`d'") (`n') (`r') ("`m'") (_b[NDE:r1vs0.a]) (_se[NDE:r1vs0.a]) (_b[NIE:r1vs0.a]) ///
					(_se[NIE:r1vs0.a]) `r2' (e(N))
			}
		}
	}
}
postclose `pf'

capture program drop nr_truth
program nr_truth
	quietly generate double tde = .
	quietly generate double tie = .
	quietly replace tde = .41754 if design == "nb"
	quietly replace tie = .24219 if design == "nb"
	quietly replace tde = 0.0924805102 if design == "nc"
	quietly replace tie = 0.1332317623 if design == "nc"
	quietly replace tde = cond(t == 1, .38, .66) if design == "nm"
	quietly replace tie = cond(t == 1, .16, .35) if design == "nm"
end
use "C:\Users\Ariel\Desktop\MMWSMED\nr_sim_results.dta", clear
quietly reshape long de se_de ie se_ie, i(design n rep method) j(t)
quietly drop if t == 2 & design != "nm"
nr_truth
foreach e in de ie {
	generate double sqe_`e' = (`e' - t`e')^2
	generate byte cov_`e' = abs(`e' - t`e') <= invnormal(.975)*se_`e' if !missing(`e')
}
collapse (mean) de ie tde tie se_de se_ie mse_de=sqe_de mse_ie=sqe_ie cov_de cov_ie nused (sd) sd_de=de sd_ie=ie ///
	(count) nrep=de, by(design t n method)
foreach e in de ie {
	generate double bias_`e' = `e' - t`e'
	generate double sebias_`e' = se_`e' - sd_`e'
	bysort design t n: egen double nb_`e' = max(cond(method == "naive", bias_`e', .))
	bysort design t n: egen double nv_`e' = max(cond(method == "naive", sd_`e'^2, .))
	generate double remov_`e' = 1 - abs(bias_`e')/abs(nb_`e')
	generate double releff_`e' = nv_`e'/sd_`e'^2
}
generate byte morder = 0
local k 0
foreach m of local methods {
	local ++k
	quietly replace morder = `k' if method == "`m'"
}
generate byte dorder = cond(design == "nb", 1, cond(design == "nc", 2, 3))
sort dorder t n morder
format tde tie bias_* sebias_* remov_* releff_* mse_* cov_* sd_* se_* %7.3f
format nused %7.1f
foreach e in ie de {
	di _n as txt cond("`e'" == "de", "Natural direct effect (NDE)", "Natural indirect effect (NIE)")
	list design t n method t`e' bias_`e' remov_`e' releff_`e' mse_`e' sd_`e' se_`e' cov_`e' nused nrep, ///
		sepby(design t n) noobs abbreviate(12)
}
save "C:\Users\Ariel\Desktop\MMWSMED\nr_sim_summary.dta", replace

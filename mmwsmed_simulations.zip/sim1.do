* sim1.do

version 16
clear all
set more off
local reps 1000

capture program drop hdh_gen
program hdh_gen
	args n a0 a1 th1 th2 th3
	drop _all
	quietly set obs `n'
	forvalues j = 1/3 {
		quietly generate double x`j' = rnormal()
	}
	quietly generate byte a = runiform() < .5
	quietly generate double u = runiform()
	quietly generate byte z0 = u < invlogit(`a0' + x1 + .5*x2)
	quietly generate byte z1 = u < invlogit(`a1' + .5*x2 + x3)
	quietly generate byte z = cond(a == 1, z1, z0)
	quietly generate double y = cond(a == 0 & z == 0, 0, cond(a == 1 & z == 0, `th1', cond(a == 0 & z == 1, `th2', `th1' + `th2' + `th3'))) ///
		+ .5*(x1 + x2 + x3) + rnormal()
end

local a0_a -0.5505294554
local a1_a 0.8332440052
local th1_a 0.3918000000
local th2_a 1.0000000000
local th3_a -1.0000000000
local DE_a 0.0000000000
local IE_a -0.0000000000
local a0_b -0.5505294554
local a1_b 0.8332440052
local th1_b 2.1582000000
local th2_b 0.5000000000
local th3_b -3.5000000000
local DE_b 0.7869000000
local IE_b -0.8073000000
local a0_c -1.7538484123
local a1_c 1.7568907223
local th1_c 1.1124000000
local th2_c 0.5000000000
local th3_c -1.7500000000
local DE_c 0.7732500000
local IE_c -0.7660000000

set seed 2015
tempname pf
postfile `pf' str1 scen int n int rep str7 method double(de se_de ie se_ie) int nused using "C:\Users\Ariel\Desktop\MMWSMED\hdh_sim_results.dta", replace
foreach sc in a b c {
	foreach n in 5000 800 {
		di as txt _n "scenario `sc', N = `n'" _c
		forvalues r = 1/`reps' {
			if mod(`r', 50) == 0 di as txt "." _c
			hdh_gen `n' `a0_`sc'' `a1_`sc'' `th1_`sc'' `th2_`sc'' `th3_`sc''
			foreach m in naive rmpw rmpw_ts nrmpw3 nrmpw4 {
				if "`m'" == "naive"   local cmd mmwsmed (y) (z, logit) (a), all knownweights
				if "`m'" == "rmpw"    local cmd mmwsmed (y) (z x1 x2 x3, logit) (a), all knownweights
				if "`m'" == "rmpw_ts" local cmd mmwsmed (y) (z x1 x2 x3, logit) (a), all vce(twostep)
				if "`m'" == "nrmpw3"  local cmd mmwsmed (y) (z x1 x2 x3, logit) (a), all nonparametric strata(3 3) knownweights
				if "`m'" == "nrmpw4"  local cmd mmwsmed (y) (z x1 x2 x3, logit) (a), all nonparametric strata(4 4) knownweights
				capture quietly `cmd'
				if _rc post `pf' ("`sc'") (`n') (`r') ("`m'") (.) (.) (.) (.) (.)
				else post `pf' ("`sc'") (`n') (`r') ("`m'") (_b[NDE:r1vs0.a]) (_se[NDE:r1vs0.a]) (_b[NIE:r1vs0.a]) (_se[NIE:r1vs0.a]) (e(N))
			}
		}
	}
}
postclose `pf'

use "C:\Users\Ariel\Desktop\MMWSMED\hdh_sim_results.dta", clear
generate double tde = .
generate double tie = .
foreach sc in a b c {
	quietly replace tde = `DE_`sc'' if scen == "`sc'"
	quietly replace tie = `IE_`sc'' if scen == "`sc'"
}
foreach e in de ie {
	generate double sqe_`e' = (`e' - t`e')^2
	generate byte cov_`e' = abs(`e' - t`e') <= invnormal(.975)*se_`e' if !missing(`e')
}
collapse (mean) de ie tde tie se_de se_ie mse_de=sqe_de mse_ie=sqe_ie cov_de cov_ie (sd) sd_de=de sd_ie=ie (count) nrep=de, by(scen n method)
foreach e in de ie {
	generate double bias_`e' = `e' - t`e'
	generate double sebias_`e' = se_`e' - sd_`e'
	bysort scen n: egen double nb_`e' = max(cond(method == "naive", bias_`e', .))
	bysort scen n: egen double nv_`e' = max(cond(method == "naive", sd_`e'^2, .))
	generate double remov_`e' = 1 - abs(bias_`e')/abs(nb_`e')
	generate double releff_`e' = nv_`e'/sd_`e'^2
}
generate byte morder = cond(method == "rmpw", 1, cond(method == "nrmpw3", 2, cond(method == "nrmpw4", 3, cond(method == "rmpw_ts", 4, 5))))
sort scen n morder
format bias_* sebias_* remov_* releff_* mse_* cov_* %7.3f
foreach e in de ie {
	di _n as txt cond("`e'" == "de", "Direct effect", "Indirect effect")
	list scen n method remov_`e' releff_`e' mse_`e' bias_`e' sebias_`e' cov_`e' nrep if method != "rmpw_ts", sepby(scen n) noobs abbreviate(12)
}
di _n as txt "Standard errors of parametric RMPW: default (cluster) vs. vce(twostep)"
list scen n method sebias_de cov_de sebias_ie cov_ie if inlist(method, "rmpw", "rmpw_ts"), sepby(scen n) noobs abbreviate(12)
save "C:\Users\Ariel\Desktop\MMWSMED\hdh_sim_summary.dta", replace

* sim5.do

version 16
clear all
set more off
local blocks 1 2 3 4 5
local reps 1000
local reps5 500
local B 200

capture program drop nr2_gen
program nr2_gen
	args d n
	drop _all
	quietly set obs `n'
	if "`d'" == "ct" {
		quietly generate double x1 = rnormal()
		quietly generate double x2 = rnormal()
		quietly generate double t = 1 + .5*x1 + .5*x2 + rnormal()
		quietly generate double m = .5 + .6*t + .4*x1 + .3*x2 + rnormal()
		quietly generate double y = .3*t + .5*m + .2*t*m + .5*x1 + .5*x2 + rnormal()
		exit
	}
	forvalues j = 1/3 {
		quietly generate double x`j' = rnormal()
	}
	quietly generate double w1 = rnormal()
	quietly generate byte w2 = runiform() < .5
	local sx (x1 + x2 + x3)
	local v1 (.5*x1 - .5*x2 + .3*x3 + .8*w1 + .8*(w2 - .5))
	local v2 (-.3*x1 + .5*x2 + .5*x3 + .5*w1 - .8*(w2 - .5))
	tempvar u ls
	quietly generate double `u' = runiform()
	if inlist("`d'", "tl", "nb", "hm") quietly generate byte a = `u' < invlogit(`v1')
	else if "`d'" == "tp"              quietly generate byte a = `u' < normal(`v1'/1.6)
	else if "`d'" == "th"              quietly generate byte a = `u' < normal((`v1'/1.6)/exp(.5*w1))
	else if "`d'" == "nm" {
		quietly generate byte a = (`u' > 1/(1 + exp(`v1') + exp(`v2'))) + (`u' > (1 + exp(`v1'))/(1 + exp(`v1') + exp(`v2')))
	}
	else {
		quietly generate double `ls' = .6*`v1' + ln(`u'/(1 - `u'))
		quietly generate byte a = (`ls' > -.4) + (`ls' > .8)
	}
	if inlist("`d'", "tl", "tp", "th", "nb") {
		quietly generate byte m = runiform() < invlogit(cond(a == 1, 0.8611384443 + .5*x2 + x3, -0.5690750539 + x1 + .5*x2) + .5*w1)
		quietly generate double y = .3*a + (.6 + .3*a)*m + .5*`sx' + .4*w1 + .4*w2 + rnormal()
	}
	else if inlist("`d'", "nm", "no") {
		quietly generate byte m = runiform() < invlogit(cond(a == 0, -0.5248761443 + x1 + .5*x2, ///
			cond(a == 1, 0.5248761443 + .5*x2 + x3, 1.3149122390 + .5*`sx')) + .5*w1)
		quietly generate double y = cond(a == 0, 0, cond(a == 1, .3, .5)) + cond(a == 0, .6, cond(a == 1, .8, 1))*m ///
			+ .5*`sx' + .4*w1 + .4*w2 + rnormal()
	}
	else {
		quietly generate double m = a + .5*`sx' + .5*w1 + exp(.5*(.6*x1 + .4*a*x2))*rnormal()
		quietly generate double y = .3*a + (.5 + .2*a)*m + .5*`sx' + .4*w1 + .4*w2 + rnormal()
	}
end

local MC (m x1 x2 x3 w1, logit)
local TC a x1 x2 x3 w1 w2
local bs vce(bootstrap, reps(`B') nodots)
local d_1 tl tp th
local d_2 no
local d_3 hm
local d_4 ct
local d_5 nb nm
local n_1 800 5000
local n_2 800 5000
local n_3 800 5000
local n_4 800 5000
local n_5 800
local m_1 logit probit hetprob
local m_2 mlogit ologit oprobit odds_ml odds_ol
local m_3 const het hetx odds
local m_4 default half
local m_5 iptw_ts iptw_bs mmws5_bs mmws10_bs np_bs odds_bs
local c_1_logit     (y) `MC' (`TC'), all
local c_1_probit    (y) `MC' (`TC', probit), all
local c_1_hetprob   (y) `MC' (`TC', hetprobit(w1)), all
local c_2_mlogit    (y) `MC' (`TC'), all
local c_2_ologit    (y) `MC' (`TC', ologit), all
local c_2_oprobit   (y) `MC' (`TC', oprobit), all
local c_2_odds_ml   (y) `MC' (`TC'), all mweight(odds)
local c_2_odds_ol   (y) `MC' (`TC', ologit), all mweight(odds)
local c_3_const     (y) (m x1 x2 x3 w1) (`TC'), all
local c_3_het       (y) (m x1 x2 x3 w1) (`TC'), all heteroskedastic
local c_3_hetx      (y) (m x1 x2 x3 w1) (`TC'), all heteroskedastic(x1 x2)
local c_3_odds      (y) (m x1 x2 x3 w1) (`TC'), all mweight(odds)
local c_4_default   (y) (m x1 x2) (t x1 x2, continuous(1 2 0)), all `bs'
local c_4_half      (y) (m x1 x2) (t x1 x2, continuous(1 2 0) bwidth(HBW)), all `bs'
local c_5_iptw_ts   (y) `MC' (`TC'), all
local c_5_iptw_bs   (y) `MC' (`TC'), all `bs'
local c_5_mmws5_bs  (y) `MC' (`TC', tmethod(mmws) tstrata(5)), all `bs'
local c_5_mmws10_bs (y) `MC' (`TC', tmethod(mmws) tstrata(10)), all `bs'
local c_5_np_bs     (y) `MC' (`TC'), all nonparametric strata(3 3) `bs'
local c_5_odds_bs   (y) `MC' (`TC'), all mweight(odds) `bs'

set seed 2028
tempname pf
postfile `pf' byte block str3 design int n int rep str9 method double(de1 se_de1 ie1 se_ie1 de2 se_de2 ie2 se_ie2) ///
	int nused int nmis using "C:\Users\Ariel\Desktop\MMWSMED\nr2_sim_results.dta", replace
foreach k of local blocks {
	local R = cond(`k' == 5, `reps5', `reps')
	foreach d of local d_`k' {
		local tv = cond("`d'" == "ct", "t", "a")
		local two = inlist("`d'", "no", "nm", "ct")
		foreach n of local n_`k' {
			di as txt _n "block `k', design `d', N = `n'" _c
			forvalues r = 1/`R' {
				if mod(`r', 50) == 0 di as txt "." _c
				nr2_gen `d' `n'
				if "`d'" == "ct" {
					quietly summarize t
					local h = r(sd)*2.34/r(N)^0.25/2
				}
				foreach m of local m_`k' {
					local cmd `c_`k'_`m''
					if "`m'" == "half" local cmd : subinstr local cmd "HBW" "`h'"
					capture quietly mmwsmed `cmd'
					if _rc {
						post `pf' (`k') ("`d'") (`n') (`r') ("`m'") (.) (.) (.) (.) (.) (.) (.) (.) (.) (.)
						continue
					}
					local r2 (.) (.) (.) (.)
					if `two' local r2 (_b[NDE:r2vs0.`tv']) (_se[NDE:r2vs0.`tv']) (_b[NIE:r2vs0.`tv']) (_se[NIE:r2vs0.`tv'])
					local nm = cond(missing(e(N_misreps)), 0, e(N_misreps))
					post `pf' (`k') ("`d'") (`n') (`r') ("`m'") (_b[NDE:r1vs0.`tv']) (_se[NDE:r1vs0.`tv']) ///
						(_b[NIE:r1vs0.`tv']) (_se[NIE:r1vs0.`tv']) `r2' (e(N)) (`nm')
				}
			}
		}
	}
}
postclose `pf'

use "C:\Users\Ariel\Desktop\MMWSMED\nr2_sim_results.dta", clear
quietly reshape long de se_de ie se_ie, i(block design n rep method) j(t)
quietly drop if t == 2 & !inlist(design, "no", "nm", "ct")
quietly generate double tde = .
quietly generate double tie = .
quietly replace tde = .41754 if inlist(design, "tl", "tp", "th", "nb")
quietly replace tie = .24219 if inlist(design, "tl", "tp", "th", "nb")
quietly replace tde = cond(t == 1, .38, .66) if inlist(design, "nm", "no")
quietly replace tie = cond(t == 1, .16, .35) if inlist(design, "nm", "no")
quietly replace tde = .3 if design == "hm"
quietly replace tie = .7 if design == "hm"
quietly replace tde = cond(t == 1, .52, -.52) if design == "ct"
quietly replace tie = cond(t == 1, .54, -.30) if design == "ct"
foreach e in de ie {
	quietly generate double sqe_`e' = (`e' - t`e')^2
	quietly generate byte cov_`e' = abs(`e' - t`e') <= invnormal(.975)*se_`e' if !missing(`e')
}
quietly generate byte fail = missing(de)
collapse (mean) de ie tde tie se_de se_ie mse_de=sqe_de mse_ie=sqe_ie cov_de cov_ie nmis (sd) sd_de=de sd_ie=ie ///
	(sum) nfail=fail (count) nrep=de, by(block design t n method)
foreach e in de ie {
	quietly generate double bias_`e' = `e' - t`e'
	quietly generate double rmse_`e' = sqrt(mse_`e')
}
generate byte morder = 0
forvalues k = 1/5 {
	local j 0
	foreach m of local m_`k' {
		local ++j
		quietly replace morder = `j' if block == `k' & method == "`m'"
	}
}
generate byte dorder = 0
local j 0
foreach d in tl tp th no hm ct nb nm {
	local ++j
	quietly replace dorder = `j' if design == "`d'"
}
sort block dorder t n morder
format tde tie bias_* rmse_* cov_* sd_* se_* %7.3f
format nmis %6.1f
forvalues k = 1/5 {
	if !`: list k in blocks' continue
	foreach e in ie de {
		di _n as res "Block `k': " cond("`e'" == "de", "natural direct effect (NDE)", "natural indirect effect (NIE)")
		list design t n method t`e' bias_`e' sd_`e' se_`e' cov_`e' rmse_`e' nfail nmis nrep if block == `k', ///
			sepby(design t n) noobs abbreviate(12)
	}
}
save "C:\Users\Ariel\Desktop\MMWSMED\nr2_sim_summary.dta", replace

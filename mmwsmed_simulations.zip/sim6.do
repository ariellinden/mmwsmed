* sim6.do

version 16
clear all
set more off
local blocks 1 2
local reps 1000

capture program drop nr3_gen
program nr3_gen
	args d n
	drop _all
	quietly set obs `n'
	forvalues j = 1/3 {
		quietly generate double x`j' = rnormal()
	}
	quietly generate double w1 = rnormal()
	quietly generate byte w2 = runiform() < .5
	local sx (x1 + x2 + x3)
	local v1 (.5*x1 - .5*x2 + .3*x3 + .8*w1 + .8*(w2 - .5))
	local lev = real(substr("`d'", 2, 2))/100
	if substr("`d'", 1, 1) == "t" {
		quietly generate byte a = runiform() < normal((`v1'/1.6)/exp(`lev'*w1))
		quietly generate byte m = runiform() < invlogit(cond(a == 1, 0.8611384443 + .5*x2 + x3, -0.5690750539 + x1 + .5*x2) + .5*w1)
		quietly generate double y = .3*a + (.6 + .3*a)*m + .5*`sx' + .4*w1 + .4*w2 + rnormal()
	}
	else {
		quietly generate byte a = runiform() < invlogit(`v1')
		quietly generate double m = a + .5*`sx' + .5*w1 + exp(.5*(1.5*`lev'*x1 + `lev'*a*x2))*rnormal()
		quietly generate double y = .3*a + (.5 + .2*a)*m + .5*`sx' + .4*w1 + .4*w2 + rnormal()
	}
end

local MC (m x1 x2 x3 w1, logit)
local TC a x1 x2 x3 w1 w2
local d_1 t50 t25 t10
local d_2 h40 h20 h10 h00
local m_1 logit probit hetprob
local m_2 const het hetx odds
local c_1_logit     (y) `MC' (`TC'), all
local c_1_probit    (y) `MC' (`TC', probit), all
local c_1_hetprob   (y) `MC' (`TC', hetprobit(w1)), all
local c_2_const     (y) (m x1 x2 x3 w1) (`TC'), all
local c_2_het       (y) (m x1 x2 x3 w1) (`TC'), all heteroskedastic
local c_2_hetx      (y) (m x1 x2 x3 w1) (`TC'), all heteroskedastic(x1 x2)
local c_2_odds      (y) (m x1 x2 x3 w1) (`TC'), all mweight(odds)

set seed 2031
tempname pf W
postfile `pf' byte block str3 design int n int rep str7 method double(de se_de ie se_ie essmin shmax) int nused ///
	using "C:\Users\Ariel\Desktop\MMWSMED\nr3_sim_results.dta", replace
foreach k of local blocks {
	foreach d of local d_`k' {
		foreach n in 800 5000 {
			di as txt _n "block `k', design `d', N = `n'" _c
			forvalues r = 1/`reps' {
				if mod(`r', 50) == 0 di as txt "." _c
				nr3_gen `d' `n'
				foreach m of local m_`k' {
					capture quietly mmwsmed `c_`k'_`m''
					if _rc {
						post `pf' (`k') ("`d'") (`n') (`r') ("`m'") (.) (.) (.) (.) (.) (.) (.)
						continue
					}
					matrix `W' = e(wdiag)
					local essmin .
					local shmax .
					forvalues i = 1/`=rowsof(`W')' {
						local essmin = min(`essmin', `W'[`i', 7])
						local shmax = max(`shmax', `W'[`i', 5])
					}
					post `pf' (`k') ("`d'") (`n') (`r') ("`m'") (_b[NDE:r1vs0.a]) (_se[NDE:r1vs0.a]) ///
						(_b[NIE:r1vs0.a]) (_se[NIE:r1vs0.a]) (`essmin') (`shmax') (e(N))
				}
			}
		}
	}
}
postclose `pf'

use "C:\Users\Ariel\Desktop\MMWSMED\nr3_sim_results.dta", clear
quietly generate double tde = cond(block == 1, .41754, .3)
quietly generate double tie = cond(block == 1, .24219, .7)
foreach e in de ie {
	quietly generate double sqe_`e' = (`e' - t`e')^2
	quietly generate byte cov_`e' = abs(`e' - t`e') <= invnormal(.975)*se_`e' if !missing(`e')
}
quietly generate byte fail = missing(de)
quietly generate byte ess5 = essmin < 5 if !missing(essmin)
collapse (mean) de ie tde tie se_de se_ie mse_de=sqe_de mse_ie=sqe_ie cov_de cov_ie essmin shmax ess5 ///
	(sd) sd_de=de sd_ie=ie (sum) nfail=fail (count) nrep=de, by(block design n method)
foreach e in de ie {
	quietly generate double bias_`e' = `e' - t`e'
	quietly generate double rmse_`e' = sqrt(mse_`e')
}
generate byte morder = 0
forvalues k = 1/2 {
	local j 0
	foreach m of local m_`k' {
		local ++j
		quietly replace morder = `j' if block == `k' & method == "`m'"
	}
}
generate byte dorder = 0
local j 0
foreach d in t50 t25 t10 h40 h20 h10 h00 {
	local ++j
	quietly replace dorder = `j' if design == "`d'"
}
sort block dorder n morder
format tde tie bias_* rmse_* cov_* sd_* se_* ess5 %7.3f
format essmin shmax %6.1f
foreach k of local blocks {
	foreach e in ie de {
		di _n as res "Block `k': " cond("`e'" == "de", "natural direct effect (NDE)", "natural indirect effect (NIE)")
		list design n method t`e' bias_`e' sd_`e' se_`e' cov_`e' rmse_`e' essmin shmax ess5 nfail nrep if block == `k', ///
			sepby(design n) noobs abbreviate(12)
	}
}
save "C:\Users\Ariel\Desktop\MMWSMED\nr3_sim_summary.dta", replace

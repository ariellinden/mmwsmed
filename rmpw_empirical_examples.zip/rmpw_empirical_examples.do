* Replicates the NSDUH (Section 3.1) and Riverside (Section 3.2) empirical illustrations in Linden (2026); requires -mmwsmed- (downloadable from SSC)
version 15
clear all
set more off
capture log close
log using "rmpw_empirical_examples.smcl", replace

use "NSDUH_female.dta", clear
egen long psu = group(vestr verep)
local X i.age i.race i.educ i.income i.employ
local B reps(1000) seed(20261108) cluster(psu)

tabulate cig15 lgb_flag, column
tabulate cigmon lgb_flag, column

mmwsmed (cigmon) (cig15 `X', logit) (lgb_flag `X'), all diagnostics
mmwsmed (cigmon) (cig15 `X', logit) (lgb_flag `X'), all mweight(odds) diagnostics
mmwsmed (cigmon) (cig15 `X', logit) (lgb_flag `X'), all nonparametric diagnostics
mmwsmed (cigmon) (cig15 `X', logit) (lgb_flag `X'), all nonparametric vce(bootstrap, `B')
mmwsmed (cigmon) (cig15 `X', logit) (lgb_flag `X', probit), all diagnostics
mmwsmed (cigmon) (cig15 `X', logit) (lgb_flag `X'), all common

mmwsmed (cigmon) (cig15 `X', logit) (lgb_flag `X') [pw=NSDUHwt], all diagnostics
mmwsmed (cigmon) (cig15 `X', logit) (lgb_flag `X') [pw=NSDUHwt], all vce(cluster psu)
mmwsmed (cigmon) (cig15 `X', logit) (lgb_flag `X') [pw=NSDUHwt], all vce(bootstrap, `B')
estat bootstrap, normal percentile bc
mmwsmed (cigmon) (cig15 `X', logit) (lgb_flag `X') [pw=NSDUHwt], all mweight(odds) diagnostics
mmwsmed (cigmon) (cig15 `X', logit) (lgb_flag `X') [pw=NSDUHwt], all nonparametric diagnostics
mmwsmed (cigmon) (cig15 `X', logit) (lgb_flag `X') [pw=NSDUHwt], all nonparametric vce(bootstrap, `B')
mmwsmed (cigmon) (cig15 `X', logit) (lgb_flag `X', probit) [pw=NSDUHwt], all diagnostics
mmwsmed (cigmon) (cig15 `X', logit) (lgb_flag `X') [pw=NSDUHwt], all common

use "Riverside.dta", clear
local Z emp_prior pqtrunc30 pqtrunc49 pqtrunc50 pqtrunc51 pqtrunc52 pqtrunc53 hispanic nevmar
local R reps(1000) seed(20261028)

tabulate emp treat, column

mmwsmed (trunc_dep12sm2 `Z') (emp `Z', logit) (treat), all diagnostics
mmwsmed (trunc_dep12sm2 `Z') (emp `Z', logit) (treat), all vce(bootstrap, `R')
mmwsmed (trunc_dep12sm2 `Z') (emp_cat `Z', ologit) (treat), all diagnostics
mmwsmed (trunc_dep12sm2 `Z') (emp_cat `Z', ologit) (treat), all vce(bootstrap, `R')
mmwsmed (trunc_dep12sm2 `Z') (emp_cat `Z', mlogit) (treat), all diagnostics
mmwsmed (trunc_dep12sm2 `Z') (emp_cont `Z') (treat), all mweight(odds) diagnostics
mmwsmed (trunc_dep12sm2 `Z') (emp_cont `Z') (treat), all mweight(odds) vce(bootstrap, `R')

log close
